
const SelectPerPage = ({itensPerPage, setItensPerPage}) =>{
    return(
        <div>
            <select value={itensPerPage} onChange={(e) => setItensPerPage(Number(e.target.value))}>
                <option value="6">6</option>
                <option value="12">12</option>
                <option value="18">18</option>
                <option value="24">24</option>
            </select> <span>itens por página</span>
        </div>
    );
}

export default SelectPerPage