
const Paginagion = ({currentPage, setCurrentPag, pages}) =>
{
    return(
        <div>
            <nav aria-label="Page navigation example">
                <ul className="pagination justify-content-center">
                    <li className="page-item">
                        <a className="page-link" href="#" onClick={()=>                            setCurrentPag(0)}>Prmeira</a>
                    </li>

                    <li className="page-item">
                        <a className="page-link" href="#" onClick={()=>                            (currentPage <= 0) ? setCurrentPag(0) : setCurrentPag(currentPage - 1)}>Anterior</a>
                    </li>
                    
                    <li className="page-item active" aria-current="page">
                        <a className="page-link">{currentPage + 1}</a>
                    </li>

                    <li className="page-item">
                        <a className="page-link" href="#" onClick={()=>(currentPage >= (pages - 1)) ? setCurrentPag(currentPage) : setCurrentPag(currentPage + 1)}>Próxima
                        </a>
                    </li>  

                    <li className="page-item">
                        <a className="page-link" href="#" onClick={()=> setCurrentPag(pages - 1)}>Ultima
                        </a>
                    </li> 
                </ul>
            </nav>
        </div>
    );
}

export default Paginagion;