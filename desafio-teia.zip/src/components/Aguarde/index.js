
function Aguarde(){

    return(
        <div className='text-center'>
            <button className="btn btn-primary" type="button" disabled>
                <span className="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
                 Carregando ...
            </button>
        </div>
        );
}

export default Aguarde;