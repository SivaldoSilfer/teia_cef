import './barraNavegacao.css';

function BarraNavegacao({setOrdenar, setOrdenarDesc, busca, setBusca})
{
    return(
        <div className="navbar navbar-expand-lg bg-light">            
            &nbsp;
            <button type="button" className="btn btn-outline-primary afasta" onClick={()=>{setOrdenar(true)}}>(A a Z) por título</button> &nbsp;

            <button type="button" className="btn btn-outline-primary afasta" onClick={()=>{setOrdenarDesc(true)}}>(Z a A) por título</button> &nbsp;

            <form className="d-flex afasta" role="search">
                <input className='form-control me-2' placeholder="Pesquisar por título" type="text" value={busca} onChange={(e)=>setBusca(e.target.value)}/>
            </form>
            
        </div> 
    );
}

export default BarraNavegacao;