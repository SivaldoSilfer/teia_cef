import {useState, useEffect} from 'react';
import SelectPerPage from '../../components/SelectPerPage';
import Paginagion from '../../components/Paginagion';
import CardPhotos from '../CardPhotos';
import BarraNavegacao from '../BarraNavegacao';

function ContainerPhotos({photos}){
    let phot = photos;
    const [itensPerPage, setItensPerPage] = useState(12); //12 fotos por página
    const [currentPage, setCurrentPag] = useState(0); // começa na página zero
    let pages = Math.ceil(phot.length / itensPerPage); //número total de páginas 
    let startIndex = currentPage * itensPerPage; // o início da página atual
    let endIndex = startIndex + itensPerPage;//o final da página atual
    let currentItens = phot.slice(startIndex, endIndex); //as fotos da página atual
    const [busca, setBusca] = useState('');
    const [ordenar, setOrdenar] = useState(false);
    const [ordenarDesc, setOrdenarDesc] = useState(false);     

  useEffect(() => {
    if(ordenar){
       //send the request
       setOrdenar(false);
    }
  },
  [ordenar]);

  useEffect(() => {
    if(ordenarDesc){
       //send the request
       setOrdenarDesc(false);
    }
  },
  [ordenarDesc]);

    if(busca != ''){//recebe
        phot = phot.filter(foto => (foto.title.toLowerCase().includes(busca.toLowerCase())));

        if(phot.length > 0){
            pages = Math.ceil(phot.length / itensPerPage);
            startIndex = currentPage * itensPerPage;
            endIndex = startIndex + itensPerPage;    
            currentItens = phot.slice(startIndex, endIndex);

            if(currentPage > pages)//se a pagina atual for maior que o número de páginas
                setCurrentPag(pages - 1); //a página atual recebe o números de páginas
        }else{//busca não achou nada
            pages = 1;
            startIndex = 0;
            endIndex = 0;    
            currentItens = phot.slice(startIndex, endIndex);
        }
        
    }

    if(ordenar){
        phot = phot.sort(function(a,b) {
            return a.title < b.title ? -1 : a.title > b.title ? 1 : 0;
        });
        setOrdenar(false);
    }

    if(ordenarDesc){
        phot = phot.sort(function(a,b) {
            return a.title > b.title ? -1 : a.title < b.title ? 1 : 0;
        });
        setOrdenarDesc(false);
    }

    return(
        <div key={1}>       
            <BarraNavegacao setOrdenar={setOrdenar} setOrdenarDesc={setOrdenarDesc} busca={busca} setBusca={setBusca}/>         
            <SelectPerPage itensPerPage={itensPerPage} setItensPerPage={setItensPerPage}/>
            <CardPhotos currentItens={currentItens}/>
            <Paginagion currentPage={currentPage} setCurrentPag={setCurrentPag} pages={pages}/>
        </div>

    );
}

export default ContainerPhotos;