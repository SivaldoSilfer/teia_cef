import {useState, useEffect} from 'react';
import { Link } from 'react-router-dom';
import SelectPerPage from '../../components/SelectPerPage';
import Paginagion from '../../components/Paginagion';

function ContainerPhotos({photos}){
    let phot = photos;
    const [itensPerPage, setItensPerPage] = useState(12); //12 fotos por página
    const [currentPage, setCurrentPag] = useState(0); // começa na página zero
    let pages = Math.ceil(phot.length / itensPerPage); //número total de páginas 
    let startIndex = currentPage * itensPerPage; // o início da página atual
    let endIndex = startIndex + itensPerPage;//o final da página atual
    let currentItens = phot.slice(startIndex, endIndex); //as fotos da página atual
    const [busca, setBusca] = useState('');
    const [ordenar, setOrdenar] = useState(false); 

    

  useEffect(() => {
    if(ordenar){
       //send the request
       setOrdenar(false);
    }
  },
  [ordenar]);

    if(busca != ''){//recebe
        phot = phot.filter(foto => (foto.title.toLowerCase().includes(busca.toLowerCase())));

        if(phot.length > 0){
            pages = Math.ceil(phot.length / itensPerPage);
            startIndex = currentPage * itensPerPage;
            endIndex = startIndex + itensPerPage;    
            currentItens = phot.slice(startIndex, endIndex);

            if(currentPage > pages)//se a pagina atual for maior que o número de páginas
                setCurrentPag(pages - 1); //a página atual recebe o números de páginas
        }
        
    }

    if(ordenar){
        phot = phot.sort(function(a,b) {
            return a.title < b.title ? -1 : a.title > b.title ? 1 : 0;
        });
        
    }

    return(
        <div key={1}>       
            <div className="navbar navbar-expand-lg bg-light">
            
                &nbsp;
                    <button type="button" className="btn btn-outline-primary" onClick={()=>{setOrdenar(true)
                    }}>Ordenar por título</button> &nbsp;

                <form className="d-flex" role="search">
                    <input className='form-control me-2' placeholder="Pesquisar por título" type="text" value={busca} onChange={(e)=>setBusca(e.target.value)}/>
                </form>
                <SelectPerPage itensPerPage={itensPerPage} setItensPerPage={setItensPerPage}/>
            </div>           
            
            <div className='row'>
                {currentItens.map((foto) =>{
                    return(
                        <div className='container text-center col-2' key={foto.id}>                        
                            <figure className="figure">     
                                <blockquote className="blockquote"><Link to={"/photos/" + foto.id}>Photo {foto.id}</Link></blockquote>                   
                                <img src={foto.thumbnailUrl} className='figure-img img-fluid rounded' alt={foto.title}/>
                                <figcaption className="figure-caption small">{foto.title.substring(0,13)}</figcaption>                               
                            </figure>
                        </div>
                    );
                })}
            </div>
            <Paginagion currentPage={currentPage} setCurrentPag={setCurrentPag} pages={pages}/>
        </div>

    );
}

export default ContainerPhotos;