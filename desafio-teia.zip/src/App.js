import RoutesApp from "./router";
import './bootstrap.min.css';

function App()
{
  return(
  <div className="App container">
    <RoutesApp/>
  </div>
  );
}

export default App;