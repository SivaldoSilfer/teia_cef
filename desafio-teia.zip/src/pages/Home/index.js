import {useEffect, useState} from 'react';
import api from '../../services/api';
import './home.css'
import { Link } from 'react-router-dom';
import Aguarde from '../../components/Aguarde';
import SelectPerPage from '../../components/SelectPerPage';
import ContainerPhotos from '../../components/ContainerPhotos';


                     
function Home(){
    const [photos, setPhotos] = useState([]);
    const [loading, setLoading] = useState(true);

    useEffect(()=>{
        async function loadPhotos(){
            const response = await api.get("photos");
            setPhotos(response.data);
            setLoading(false);
        }

        loadPhotos();
    }, []);

    if(loading){
        return(
        <Aguarde/>
        );
    }

    return(
        <ContainerPhotos photos={photos}/>
    );
}

export default Home;