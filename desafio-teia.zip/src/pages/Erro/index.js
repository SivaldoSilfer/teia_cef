
function Erro(){
    return(
        <div className="alert alert-danger" role="alert">
            <h1 className="display-1">Página não encontrada!!!</h1>
        </div>
    );
}

export default Erro;