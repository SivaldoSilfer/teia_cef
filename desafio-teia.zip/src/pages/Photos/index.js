import { useParams } from "react-router-dom";
import {useEffect, useState} from 'react';
import api from '../../services/api';
import Aguarde from '../../components/Aguarde';

function Photos(){

    const{ id } = useParams();
    const [loading, setLoading] = useState(true);
    const [photo, setPhoto] = useState([]);

    useEffect(()=>{
        async function loadPhotos(){
            const url = "photos/?id=" + id;
            const response = await api.get(url);
            setPhoto(response.data);
            setLoading(false);
        }

        loadPhotos();
    }, []);    


    if(loading){
        return(
        <Aguarde/>
        );
    }

    return(
        <div>
              
            {photo.map((foto) =>{
                return(
                    <div key={foto.id} className="row">                        
                        <div className="col-7">
                            <figure className="figure">                   
                                <img src={foto.url} className='figure-img img-fluid rounded' alt={foto.title}/>                                
                            </figure>
                        </div>
                        <div className="col-5">
                            <h1>Photo {id}</h1>
                            <h2>{foto.title}</h2>
                        </div>
                    </div>
                );
            })}
        </div>
        
    );
}

export default Photos;